﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Grzmotoptak.Data.Migrations
{
    /// <inheritdoc />
    public partial class abc : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_events_AspNetUsers_UserId",
                table: "events");

            migrationBuilder.DropIndex(
                name: "IX_events_UserId",
                table: "events");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "events");

            migrationBuilder.AlterColumn<string>(
                name: "tworca_id",
                table: "events",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_events_tworca_id",
                table: "events",
                column: "tworca_id");

            migrationBuilder.AddForeignKey(
                name: "FK_events_AspNetUsers_tworca_id",
                table: "events",
                column: "tworca_id",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_events_AspNetUsers_tworca_id",
                table: "events");

            migrationBuilder.DropIndex(
                name: "IX_events_tworca_id",
                table: "events");

            migrationBuilder.AlterColumn<string>(
                name: "tworca_id",
                table: "events",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "events",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_events_UserId",
                table: "events",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_events_AspNetUsers_UserId",
                table: "events",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
