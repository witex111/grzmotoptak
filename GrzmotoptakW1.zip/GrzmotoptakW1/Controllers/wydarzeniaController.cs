﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Grzmotoptak.Data;
using Grzmotoptak.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace Grzmotoptak.Controllers
{
    public class wydarzeniaController : Controller
    {
        private readonly ApplicationDbContext _context;

        public wydarzeniaController(ApplicationDbContext context)
        {
            _context = context;
        }

        private bool wydarzeniaExists(int id)
        {
            return _context.events.Any(e => e.Id == id);
        }

        // GET: wydarzenia
        public async Task<IActionResult> Index(string searchString)
        {
            var wydarzenia = from e in _context.events
                             select e;

            if (!String.IsNullOrEmpty(searchString))
            {
                wydarzenia = wydarzenia.Where(e => e.Tytul.Contains(searchString) || e.typ.Contains(searchString));
            }

            // Pass the current search string to the view
            ViewData["CurrentFilter"] = searchString;

            return View(await wydarzenia.Include(e => e.User).ToListAsync());
        }

        // GET: wydarzenia/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var wydarzenia = await _context.events
                .Include(e => e.User) // Powiązanie z użytkownikiem
                .FirstOrDefaultAsync(m => m.Id == id);

            if (wydarzenia == null)
            {
                return NotFound();
            }

            return View(wydarzenia);
        }

        [Authorize]
        // GET: wydarzenia/Create
        public IActionResult Create()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Tytul,Opis,Data,typ")] wydarzenia wydarzenia)
        {
            wydarzenia.tworca_id = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (ModelState.IsValid)
            {
                _context.Add(wydarzenia);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(wydarzenia);
        }

        [Authorize]
        // GET: wydarzenias/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var wydarzenia = await _context.events.FindAsync(id);
            if (wydarzenia == null)
            {
                return NotFound();
            }

            // Check if the user has permission to edit
            if (wydarzenia.tworca_id != User.FindFirstValue(ClaimTypes.NameIdentifier) && !User.IsInRole("Admin"))
            {
                return Forbid(); // Return 403 Forbidden
            }

            return View(wydarzenia);
        }

        [Authorize]
        // POST: wydarzenias/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Tytul,Opis,Data,typ")] wydarzenia wydarzenia)
        {
            if (id != wydarzenia.Id)
            {
                return NotFound();
            }

            // Get the existing event from the database
            var existingEvent = await _context.events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
            if (existingEvent == null)
            {
                return NotFound();
            }

            // Check if the user has permission to edit
            if (existingEvent.tworca_id != User.FindFirstValue(ClaimTypes.NameIdentifier) && !User.IsInRole("Admin"))
            {
                return Forbid(); // Return 403 Forbidden
            }

            // Set the `tworca_id` value to the same as the existing event
            wydarzenia.tworca_id = existingEvent.tworca_id;

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(wydarzenia);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!wydarzeniaExists(wydarzenia.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(wydarzenia);
        }

        [Authorize]
        // GET: wydarzenias/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var wydarzenia = await _context.events
                .Include(e => e.User) // Powiązanie z użytkownikiem
                .FirstOrDefaultAsync(m => m.Id == id);
            if (wydarzenia == null)
            {
                return NotFound();
            }

            return View(wydarzenia);
        }

        [Authorize]
        // POST: wydarzenias/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var wydarzenia = await _context.events.FindAsync(id);

            if (wydarzenia == null)
            {
                return NotFound();
            }

            // Check if the user has permission to delete
            if (wydarzenia.tworca_id != User.FindFirstValue(ClaimTypes.NameIdentifier) && !User.IsInRole("Admin"))
            {
                return Forbid(); // Return 403 Forbidden
            }

            _context.events.Remove(wydarzenia);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        
        [Authorize]
        public async Task<IActionResult> MyEnrollments()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Pobierz zapisane wydarzenia tego użytkownika
            var enrolledEvents = await _context.Enrollments
                .Where(e => e.UserId == userId)
                .Include(e => e.Event)  
                .ToListAsync();

            return View(enrolledEvents); // Zwrócenie danych do widoku
        }



    }
}
