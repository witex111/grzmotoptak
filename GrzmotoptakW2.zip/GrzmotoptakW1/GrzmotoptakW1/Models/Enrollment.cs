﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Grzmotoptak.Models
{
    public class Enrollment
    {
        public int Id { get; set; }

        // Id użytkownika (używamy IdentityUser)
       
        public string UserId { get; set; }

        // Id wydarzenia
        [Required]
        public int EventId { get; set; }

        // Powiązanie z użytkownikiem IdentityUser
        public virtual IdentityUser User { get; set; }

        // Powiązanie z wydarzeniem
        [ForeignKey("EventId")]
        public virtual wydarzenia Event { get; set; }

        // Optional constructor for initializing the properties
        public Enrollment(string userId, int eventId)
        {
            UserId = userId;
            EventId = eventId;
        }
    }
}
