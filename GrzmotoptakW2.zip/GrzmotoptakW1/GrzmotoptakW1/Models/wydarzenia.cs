﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Permissions;
using Microsoft.AspNetCore.Identity;

namespace Grzmotoptak.Models
{
    public class wydarzenia
    {
        public int Id { get; set; }
        public string Tytul { get; set; }
        public string Opis { get; set; }
        public DateTime Data { get; set; }
        public string typ { get; set; }
        public string? tworca_id { get; set; }
        [ForeignKey("tworca_id")]
        public IdentityUser? User { get; set; }
       public virtual required ICollection<Enrollment> Enrollments { get; set; }

        // Metoda do przypisania tworca_id
        public void SetTworcaId(string userId)
        {
            if (string.IsNullOrEmpty(tworca_id))
            {
                tworca_id = userId;
            }
            
        }
    }

}

