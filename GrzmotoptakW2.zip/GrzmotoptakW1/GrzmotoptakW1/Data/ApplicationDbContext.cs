﻿using Grzmotoptak.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Grzmotoptak.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            
        }

        public DbSet<wydarzenia> events { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
    

    }

}
