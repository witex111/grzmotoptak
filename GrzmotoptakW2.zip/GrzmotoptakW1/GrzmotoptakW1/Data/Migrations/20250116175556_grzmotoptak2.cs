﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Grzmotoptak.Data.Migrations
{
    /// <inheritdoc />
    public partial class grzmotoptak2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_events_AspNetUsers_CreatorId",
                table: "events");

            migrationBuilder.DropIndex(
                name: "IX_events_CreatorId",
                table: "events");

            migrationBuilder.DropColumn(
                name: "CreatorId",
                table: "events");

            migrationBuilder.DropColumn(
                name: "Discriminator",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "IsAdmin",
                table: "AspNetUsers");

            migrationBuilder.AlterColumn<string>(
                name: "tworca_id",
                table: "events",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "events",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_events_UserId",
                table: "events",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_events_AspNetUsers_UserId",
                table: "events",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_events_AspNetUsers_UserId",
                table: "events");

            migrationBuilder.DropIndex(
                name: "IX_events_UserId",
                table: "events");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "events");

            migrationBuilder.AlterColumn<string>(
                name: "tworca_id",
                table: "events",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CreatorId",
                table: "events",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Discriminator",
                table: "AspNetUsers",
                type: "nvarchar(21)",
                maxLength: 21,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsAdmin",
                table: "AspNetUsers",
                type: "bit",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_events_CreatorId",
                table: "events",
                column: "CreatorId");

            migrationBuilder.AddForeignKey(
                name: "FK_events_AspNetUsers_CreatorId",
                table: "events",
                column: "CreatorId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
